export declare class FilePathSetEntity {
    id: number;
    lisHotKey: string;
    lisFilePath: string;
    cbcFilePath: string;
}
