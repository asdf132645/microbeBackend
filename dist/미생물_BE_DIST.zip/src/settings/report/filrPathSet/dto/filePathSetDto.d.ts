export declare class CreateFilePathSetDto {
    filePathSetItems: FilePathSetItems[];
}
export declare class FilePathSetItems {
    id: number;
    lisHotKey: string;
    lisFilePath: string;
    cbcFilePath: string;
}
