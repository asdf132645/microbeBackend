export declare class FilePathSetModule {
}
