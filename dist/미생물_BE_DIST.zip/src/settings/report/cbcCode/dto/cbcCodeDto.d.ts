export declare class CreateCbcCodeDto {
    cbcCodeItems: CbcCodeItems[];
}
export declare class CbcCodeItems {
    id: number;
    cd: string;
    classCd: string;
    fullNm: string;
    isSelected: boolean;
}
