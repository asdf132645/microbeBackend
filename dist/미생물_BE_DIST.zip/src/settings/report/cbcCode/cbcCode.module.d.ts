export declare class CbcCodeModule {
}
