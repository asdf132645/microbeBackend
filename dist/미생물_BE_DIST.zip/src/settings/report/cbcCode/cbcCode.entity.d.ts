export declare class CbcCodeEntity {
    id: number;
    cd: string;
    classCd: string;
    fullNm: string;
    isSelected: boolean;
}
