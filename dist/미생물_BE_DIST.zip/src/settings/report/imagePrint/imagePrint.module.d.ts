export declare class ImagePrintModule {
}
