export declare class ImagePrintEntity {
    id: number;
    fullNm: string;
    classId: string;
    checked: boolean;
}
