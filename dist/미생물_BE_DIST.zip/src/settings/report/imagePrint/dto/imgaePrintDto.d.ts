export declare class CreateImagePrintDto {
    imagePrintItems: ImagePrintItems[];
}
export declare class ImagePrintItems {
    id: number;
    fullNm: string;
    classId: string;
    checked: boolean;
}
