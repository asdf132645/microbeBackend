export declare class RemainingCountService {
    executeApplication(): Promise<string>;
}
