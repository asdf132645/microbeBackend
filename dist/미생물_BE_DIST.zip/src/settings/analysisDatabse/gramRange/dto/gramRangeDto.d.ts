export declare class GramRangeDto {
    gramRangeItems: gramRangeItems[];
}
export declare class gramRangeItems {
    id?: number;
    classId: string;
    rareBoundary: number;
    fewBoundary: number;
    moderateBoundary: number;
    fullNm: string;
}
