export declare class GramRange {
    id: number;
    classId: string;
    rareBoundary: number;
    fewBoundary: number;
    moderateBoundary: number;
    fullNm: string;
}
