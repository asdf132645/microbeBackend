export declare class GramRangeModule {
}
