import { GramRangeService } from './gramRange.service';
import { GramRange } from './gramRange.entity';
import { GramRangeDto } from './dto/gramRangeDto';
export declare class GramRangeController {
    private readonly gramRangeService;
    constructor(gramRangeService: GramRangeService);
    create(createDto: GramRangeDto): Promise<GramRange>;
    update(updateDto: GramRangeDto): Promise<GramRange[]>;
    find(): Promise<GramRange[]>;
}
