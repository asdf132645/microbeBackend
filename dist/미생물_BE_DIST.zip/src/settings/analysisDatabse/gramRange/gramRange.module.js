"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.GramRangeModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const gramRange_entity_1 = require("./gramRange.entity");
const gramRange_service_1 = require("./gramRange.service");
const gramRange_controller_1 = require("./gramRange.controller");
let GramRangeModule = class GramRangeModule {
};
exports.GramRangeModule = GramRangeModule;
exports.GramRangeModule = GramRangeModule = __decorate([
    (0, common_1.Module)({
        imports: [typeorm_1.TypeOrmModule.forFeature([gramRange_entity_1.GramRange])],
        providers: [gramRange_service_1.GramRangeService],
        exports: [gramRange_service_1.GramRangeService],
        controllers: [gramRange_controller_1.GramRangeController],
    })
], GramRangeModule);
//# sourceMappingURL=gramRange.module.js.map