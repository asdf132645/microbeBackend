import { Repository } from 'typeorm';
import { GramRange } from './gramRange.entity';
import { GramRangeDto } from './dto/gramRangeDto';
export declare class GramRangeService {
    private readonly gramRangeRepository;
    constructor(gramRangeRepository: Repository<GramRange>);
    create(createDto: GramRangeDto): Promise<GramRange>;
    update(updateDto: GramRangeDto): Promise<GramRange[]>;
    private updateItem;
    find(): Promise<GramRange[]>;
}
