export declare class CellImgAnalyzedModule {
}
