import { Repository } from 'typeorm';
import { CellImgAnalyzed } from './entities/cell.entity';
import { CellImgAnalyzedDto } from './dto/create-cellImg.dto';
export declare class CellImgAnalyzedService {
    private readonly cellImgAnalyzedRepository;
    constructor(cellImgAnalyzedRepository: Repository<CellImgAnalyzed>);
    create(dto: CellImgAnalyzedDto): Promise<CellImgAnalyzed>;
    find(): Promise<CellImgAnalyzed | null>;
    update(dto: CellImgAnalyzedDto): Promise<CellImgAnalyzed>;
}
