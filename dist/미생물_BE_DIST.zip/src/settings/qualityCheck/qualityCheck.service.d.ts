export declare class QualityCheckService {
    executeApplication(): Promise<string>;
}
