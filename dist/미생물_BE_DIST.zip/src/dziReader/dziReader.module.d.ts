export declare class DziReaderModule {
}
