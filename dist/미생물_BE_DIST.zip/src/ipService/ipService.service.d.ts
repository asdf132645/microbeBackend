export declare class IpService {
    getClientIp(req: any): string;
}
