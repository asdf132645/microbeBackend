export declare class IpModule {
}
