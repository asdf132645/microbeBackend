export declare class ExcelService {
    executeApplication(filesPath: any): Promise<string>;
}
