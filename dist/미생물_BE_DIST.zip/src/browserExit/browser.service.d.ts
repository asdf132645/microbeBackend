export declare class BrowserService {
    closeEdgeBrowser(): Promise<string>;
    closeNodeProcesses(): Promise<void>;
    closeAllProcesses(): Promise<void>;
}
