export declare class FolderController {
    getDrives(): string[];
    private getWindowsDrives;
    private getUnixLikeDrives;
}
