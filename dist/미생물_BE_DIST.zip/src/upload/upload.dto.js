"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UploadDto = void 0;
class UploadDto {
}
exports.UploadDto = UploadDto;
//# sourceMappingURL=upload.dto.js.map