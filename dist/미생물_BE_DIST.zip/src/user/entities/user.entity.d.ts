export declare class User {
    id: number;
    userId: string;
    password: string;
    name: string;
    employeeNo: string;
    userType: string;
    isLoggedIn: boolean;
    subscriptionDate: Date;
    latestDate: Date;
}
