"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RunningInfoService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const runningInfo_entity_1 = require("./runningInfo.entity");
const moment = require("moment");
const logger_service_1 = require("../logger.service");
const ioredis_1 = require("@nestjs-modules/ioredis");
const ioredis_2 = require("ioredis");
const child_process_1 = require("child_process");
let RunningInfoService = class RunningInfoService {
    constructor(logger, dataSource, runingInfoEntityRepository, redis) {
        this.logger = logger;
        this.dataSource = dataSource;
        this.runingInfoEntityRepository = runingInfoEntityRepository;
        this.redis = redis;
    }
    async addUniqueConstraintToSlotId() {
        try {
            const entityManager = this.runingInfoEntityRepository.manager;
            const checkQuery = `
      SELECT COUNT(*)
      FROM information_schema.TABLE_CONSTRAINTS tc
      JOIN information_schema.KEY_COLUMN_USAGE kcu
      ON tc.CONSTRAINT_NAME = kcu.CONSTRAINT_NAME
      WHERE tc.TABLE_SCHEMA = DATABASE() -- 현재 데이터베이스 선택
      AND tc.TABLE_NAME = 'runing_info_entity'
      AND tc.CONSTRAINT_TYPE = 'UNIQUE'
      AND kcu.COLUMN_NAME = 'slotId';
    `;
            const checkResult = await entityManager.query(checkQuery);
            if (checkResult[0]['COUNT(*)'] > 0) {
                console.log('UNIQUE 제약 조건이 이미 존재합니다.');
                return;
            }
            const addQuery = `
      ALTER TABLE runing_info_entity 
      ADD CONSTRAINT unique_slotId UNIQUE (slotId);
    `;
            await entityManager.query(addQuery);
            console.log('slotId에 UNIQUE 제약 조건이 추가되었습니다.');
        }
        catch (error) {
            console.log('오류 발생:', error.message);
        }
    }
    async create(createDto) {
        const { runingInfoDtoItems } = createDto;
        const analyzedDttm = moment(runingInfoDtoItems.analyzedDttm, 'YYYYMMDDHHmm');
        const startDttm = analyzedDttm.clone().subtract(1, 'hours');
        const endDttm = analyzedDttm.clone().add(1, 'hours');
        const startDttmStr = startDttm.format('YYYYMMDDHHmm');
        const endDttmStr = endDttm.format('YYYYMMDDHHmm');
        return await this.dataSource.transaction(async (manager) => {
            const existingEntity = await manager.findOne(runningInfo_entity_1.RunningInfoEntity, {
                where: {
                    slotId: runingInfoDtoItems.slotId,
                    analyzedDttm: (0, typeorm_2.Between)(startDttmStr, endDttmStr),
                },
            });
            if (existingEntity) {
                console.log('동일 슬롯아이디 및 1시간 범위 내 analyzedDttm 존재, 저장 x');
                return null;
            }
            const entity = manager.create(runningInfo_entity_1.RunningInfoEntity, {
                ...runingInfoDtoItems,
            });
            return await manager.save(entity);
        });
    }
    async findBySlotNo(slotId) {
        return this.runingInfoEntityRepository.findOne({ where: { slotId } });
    }
    async update(updateDto) {
        const { runingInfoDtoItems } = updateDto;
        const updatedItems = [];
        for (const item of runingInfoDtoItems) {
            const existingEntity = await this.runingInfoEntityRepository.findOne({
                where: { id: item.id },
            });
            if (existingEntity) {
                existingEntity.slotNo = item.slotNo;
                existingEntity.barcodeNo = item.barcodeNo;
                existingEntity.patientId = item.patientId;
                existingEntity.patientNm = item.patientNm;
                existingEntity.gender = item.gender;
                existingEntity.birthDay = item.birthDay;
                existingEntity.slotId = item.slotId;
                existingEntity.orderDttm = item.orderDttm;
                existingEntity.testType = item.testType;
                existingEntity.cbcPatientNo = item.cbcPatientNo;
                existingEntity.cbcPatientNm = item.cbcPatientNm;
                existingEntity.cbcSex = item.cbcSex;
                existingEntity.cbcAge = item.cbcAge;
                existingEntity.tactTime = item.tactTime;
                existingEntity.cassetId = item.cassetId;
                existingEntity.isNormal = item.isNormal;
                existingEntity.memo = item.memo;
                existingEntity.classInfo = item.classInfo;
                existingEntity.lock_status = item.lock_status;
                existingEntity.pcIp = item.pcIp;
                existingEntity.submitState = item.submitState;
                existingEntity.submitOfDate = item.submitOfDate;
                existingEntity.submitUserId = item.submitUserId;
                existingEntity.img_drive_root_path = item.img_drive_root_path;
                await this.runingInfoEntityRepository.save(existingEntity);
                updatedItems.push(existingEntity);
            }
        }
        return updatedItems;
    }
    async delete(ids, rootPaths) {
        await this.cleanBrowserCache();
        try {
            const result = await this.runingInfoEntityRepository.delete({
                id: (0, typeorm_2.In)(ids),
            });
            if (result.affected > 0) {
                for (const rootPath of rootPaths) {
                    (0, child_process_1.exec)(`rmdir /s /q "${rootPath}"`, (error) => {
                        if (error) {
                            console.error(`Failed to delete folder at ${rootPath}:`, error.message);
                        }
                        else {
                            console.log(`Folder at ${rootPath} has been deleted successfully`);
                        }
                    });
                }
            }
            return result.affected > 0;
        }
        catch (error) {
            console.error('Error while deleting entities:', error);
            return false;
        }
    }
    async findAllWithPagingAndFilter(page, pageSize, startDay, endDay, barcodeNo, patientId, patientNm, titles, testType) {
        const queryBuilder = this.runingInfoEntityRepository.createQueryBuilder('runInfo');
        const startFormatted = startDay
            ? `${startDay.getFullYear()}${(startDay.getMonth() + 1).toString().padStart(2, '0')}${startDay.getDate().toString().padStart(2, '0')}000000000`
            : undefined;
        const endFormatted = endDay
            ? `${endDay.getFullYear()}${(endDay.getMonth() + 1).toString().padStart(2, '0')}${endDay.getDate().toString().padStart(2, '0')}235959999`
            : undefined;
        if (startFormatted || endFormatted) {
            queryBuilder.andWhere(startFormatted && endFormatted
                ? 'runInfo.analyzedDttm BETWEEN :startDay AND :endDay'
                : startFormatted
                    ? 'runInfo.analyzedDttm >= :startDay'
                    : 'runInfo.analyzedDttm <= :endDay', {
                startDay: startFormatted,
                endDay: endFormatted,
            });
        }
        queryBuilder.orderBy('runInfo.analyzedDttm', 'DESC');
        if (barcodeNo) {
            queryBuilder.andWhere('runInfo.barcodeNo LIKE :barcodeNo', {
                barcodeNo: `%${barcodeNo}%`,
            });
        }
        if (patientId) {
            queryBuilder.andWhere('runInfo.patientId LIKE :patientId', {
                patientId: `%${patientId}%`,
            });
        }
        if (patientNm) {
            queryBuilder.andWhere('runInfo.patientNm LIKE :patientNm', {
                patientNm: `%${patientNm}%`,
            });
        }
        if (testType) {
            queryBuilder.andWhere('runInfo.testType = :testType', { testType });
        }
        if (titles && titles.length > 0) {
            const orConditions = titles
                .map((title, index) => {
                const titleParam = `title${index}`;
                return `
            (JSON_SEARCH(runInfo.classInfo, 'one', :${titleParam}, NULL, '$[*].title') IS NOT NULL
            AND (
              SELECT COUNT(*)
              FROM JSON_TABLE(
                runInfo.classInfo,
                '$[*]' COLUMNS(
                  title VARCHAR(255) PATH '$.title',
                  count INT PATH '$.count'
                )
              ) AS jt
              WHERE jt.title = :${titleParam}
                AND jt.count > 0
            ) > 0)
          `;
            })
                .join(' OR ');
            const params = titles.reduce((acc, title, index) => {
                acc[`title${index}`] = title;
                return acc;
            }, {});
            queryBuilder.andWhere(new typeorm_2.Brackets((qb) => {
                qb.where(orConditions, params);
            }));
        }
        let [data, total] = await queryBuilder.getManyAndCount();
        if (pageSize && page) {
            data = data.slice((page - 1) * pageSize, page * pageSize);
        }
        return { data, total };
    }
    async clearPcIpAndSetStateFalse(pcIp) {
        try {
            console.log(pcIp);
            const entityWithPcIp = await this.runingInfoEntityRepository.findOne({
                where: { pcIp },
            });
            if (!entityWithPcIp) {
                console.error(`Entity with PC IP ${pcIp} not found`);
                return;
            }
            entityWithPcIp.pcIp = '';
            entityWithPcIp.lock_status = false;
            await this.runingInfoEntityRepository.save(entityWithPcIp);
        }
        catch (error) {
            console.error('Error while clearing PC IP and setting state to false:', error);
        }
    }
    async getRunningInfoById(id) {
        const entity = await this.runingInfoEntityRepository.findOne({
            where: { id },
        });
        return entity || null;
    }
    async getRunningInfoClassDetail(id) {
        const entityManager = this.runingInfoEntityRepository.manager;
        const query = `
      SELECT 
        id,
        slotId,
        testType,
        barcodeNo,
        patientId,
        cbcPatientNo,
        cbcPatientNm,
        submitState,
        cbcSex,
        cbcAge,
        analyzedDttm,
        classInfo,
        img_drive_root_path,
      FROM 
        runing_info_entity
      WHERE 
        id = ?`;
        const result = await entityManager.query(query, [id]);
        if (result.length > 0) {
            return result[0];
        }
        else {
            return null;
        }
    }
    async getRunningInfoClassInfo(id) {
        const entityManager = this.runingInfoEntityRepository.manager;
        const query = `
      SELECT 
        id,
        classInfo,
        testType,
        submitState,
        img_drive_root_path
      FROM 
        runing_info_entity
      WHERE 
        id = ?`;
        const result = await entityManager.query(query, [id]);
        if (result.length > 0) {
            return result[0];
        }
        else {
            return null;
        }
    }
    async getRunningInfoClassInfoMenu(id) {
        const entityManager = this.runingInfoEntityRepository.manager;
        const query = `
      SELECT 
        id,
        lock_status,
        classInfo,
        testType,
        img_drive_root_path
      FROM 
        runing_info_entity
      WHERE 
        id = ?`;
        const result = await entityManager.query(query, [id]);
        if (result.length > 0) {
            return result[0];
        }
        else {
            return null;
        }
    }
    async getUpDownRunnInfo(id, step, type) {
        const entityManager = this.runingInfoEntityRepository.manager;
        const currentEntityQuery = `
      SELECT 
        id
      FROM 
        runing_info_entity
      WHERE 
        id = ?`;
        const currentEntityResult = await entityManager.query(currentEntityQuery, [
            id,
        ]);
        if (currentEntityResult.length === 0) {
            return null;
        }
        let newEntityQuery = '';
        if (type === 'up') {
            newEntityQuery = `
        SELECT 
          id,
          testType,
          lock_status,
          traySlot,
          barcodeNo,
          patientId,
          patientNm,
          analyzedDttm,
          tactTime,
          submitState,
          submitOfDate,
          slotNo,
          cassetId,
          slotId,
          orderDttm,
          gender,
          birthDay,
          isNormal,
          classInfo,
          submitUserId,
          memo,
          pcIp,
          cbcPatientNo,
          cbcPatientNm,
          cbcSex,
          cbcAge,
          img_drive_root_path
        FROM 
          runing_info_entity
        WHERE 
          id > ?
        ORDER BY 
          id ASC
        LIMIT 1 OFFSET ?`;
        }
        else if (type === 'down') {
            newEntityQuery = `
        SELECT 
          id,
          analyzedDttm,
          barcodeNo,
          birthDay,
          cassetId,
          cbcAge,
          cbcPatientNm,
          cbcPatientNo,
          cbcSex,
          gender,
          img_drive_root_path,
          isNormal,
          lock_status,
          orderDttm,
          patientId,
          patientNm,
          pcIp,
          slotId,
          slotNo,
          submitOfDate,
          submitState,
          submitUserId,
          tactTime,
          testType,
          traySlot,
          classInfo,
          memo
        FROM 
          runing_info_entity
        WHERE 
          id < ?
        ORDER BY 
          id DESC
        LIMIT 1 OFFSET ?`;
        }
        const newEntityResult = await entityManager.query(newEntityQuery, [
            id,
            step - 1,
        ]);
        if (newEntityResult.length > 0) {
            const result = newEntityResult[0];
            return {
                id: result.id,
                analyzedDttm: result.analyzedDttm,
                barcodeNo: result.barcodeNo,
                birthDay: result.birthDay,
                cassetId: result.cassetId,
                cbcAge: result.cbcAge,
                cbcPatientNm: result.cbcPatientNm,
                cbcPatientNo: result.cbcPatientNo,
                cbcSex: result.cbcSex,
                gender: result.gender,
                img_drive_root_path: result.img_drive_root_path,
                isNormal: result.isNormal,
                lock_status: result.lock_status,
                orderDttm: result.orderDttm,
                patientId: result.patientId,
                patientNm: result.patientNm,
                pcIp: result.pcIp,
                slotId: result.slotId,
                slotNo: result.slotNo,
                submitOfDate: result.submitOfDate,
                submitState: result.submitState,
                submitUserId: result.submitUserId,
                tactTime: result.tactTime,
                testType: result.testType,
                traySlot: result.traySlot,
                classInfo: result.classInfo,
                memo: result.memo,
            };
        }
        else {
            return null;
        }
    }
    async updatePcIpAndState(oldPcIp, newEntityId, newPcIp) {
        await this.runingInfoEntityRepository.update({ pcIp: oldPcIp }, { pcIp: '', lock_status: false });
        await this.runingInfoEntityRepository.update({ id: newEntityId }, { pcIp: newPcIp, lock_status: true });
    }
    async clearPcIpAndState(oldPcIp) {
        await this.runingInfoEntityRepository.update({ pcIp: oldPcIp }, { pcIp: '', lock_status: false });
    }
    async redisAllClear() {
        this.redis.flushall();
    }
    cleanBrowserCache() {
        return new Promise((resolve, reject) => {
            (0, child_process_1.exec)('powershell.exe -Command "Get-ChildItem \\"$env:LOCALAPPDATA\\Microsoft\\Edge\\User Data\\" -Directory | ForEach-Object { Remove-Item -Path \\"$($_.FullName)\\Cache\\Cache_Data\\f_*\\" -Recurse -ErrorAction SilentlyContinue }"', (error, stdout, stderr) => {
                if (error) {
                    return reject(error);
                }
                if (stderr) {
                    console.log(`browser cache clean warning: ${stderr}`);
                }
                resolve(stdout);
            });
        });
    }
};
exports.RunningInfoService = RunningInfoService;
exports.RunningInfoService = RunningInfoService = __decorate([
    (0, common_1.Injectable)(),
    __param(2, (0, typeorm_1.InjectRepository)(runningInfo_entity_1.RunningInfoEntity)),
    __param(3, (0, ioredis_1.InjectRedis)()),
    __metadata("design:paramtypes", [logger_service_1.LoggerService,
        typeorm_2.DataSource,
        typeorm_2.Repository,
        ioredis_2.default])
], RunningInfoService);
//# sourceMappingURL=runningInfo.service.js.map