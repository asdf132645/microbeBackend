import { Repository, DataSource } from 'typeorm';
import { RunningInfoEntity } from './runningInfo.entity';
import { CreateRuningInfoDto, UpdateRuningInfoDto } from './dto/runningInfoDtoItems';
import { LoggerService } from '../logger.service';
import Redis from 'ioredis';
export declare class RunningInfoService {
    private readonly logger;
    private readonly dataSource;
    private readonly runingInfoEntityRepository;
    private readonly redis;
    constructor(logger: LoggerService, dataSource: DataSource, runingInfoEntityRepository: Repository<RunningInfoEntity>, redis: Redis);
    addUniqueConstraintToSlotId(): Promise<void>;
    create(createDto: CreateRuningInfoDto): Promise<RunningInfoEntity>;
    findBySlotNo(slotId: string): Promise<RunningInfoEntity | undefined>;
    update(updateDto: UpdateRuningInfoDto): Promise<RunningInfoEntity[]>;
    delete(ids: string[], rootPaths: string[]): Promise<boolean>;
    findAllWithPagingAndFilter(page: number, pageSize: number, startDay?: Date, endDay?: Date, barcodeNo?: string, patientId?: string, patientNm?: string, titles?: string[], testType?: string): Promise<{
        data: RunningInfoEntity[];
        total: number;
    }>;
    clearPcIpAndSetStateFalse(pcIp: string): Promise<void>;
    getRunningInfoById(id: number): Promise<RunningInfoEntity | null>;
    getRunningInfoClassDetail(id: number): Promise<RunningInfoEntity | null>;
    getRunningInfoClassInfo(id: number): Promise<RunningInfoEntity | null>;
    getRunningInfoClassInfoMenu(id: number): Promise<RunningInfoEntity | null>;
    getUpDownRunnInfo(id: number, step: number, type: string): Promise<Partial<RunningInfoEntity> | null>;
    updatePcIpAndState(oldPcIp: string, newEntityId: number, newPcIp: string): Promise<void>;
    clearPcIpAndState(oldPcIp: string): Promise<void>;
    redisAllClear(): Promise<void>;
    private cleanBrowserCache;
}
