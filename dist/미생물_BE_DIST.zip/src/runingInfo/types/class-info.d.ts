export declare class ClassInfo {
    classId?: string;
    classNm?: string;
    degree?: string;
}
export declare class TotalClassInfo {
    classInfo?: ClassInfo[];
    categoryId?: string;
    categoryNm?: string;
}
