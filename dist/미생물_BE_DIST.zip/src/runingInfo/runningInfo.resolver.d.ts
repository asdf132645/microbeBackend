import { RunningInfoService } from './runningInfo.service';
import { RunningInfoEntity } from './runningInfo.entity';
export declare class RunningInfoResolver {
    private readonly runningInfoService;
    constructor(runningInfoService: RunningInfoService);
    getRunningInfoByIdGQL(id: number): Promise<RunningInfoEntity>;
}
