export declare class RunningInfoModule {
}
