"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateRuningInfoDto = exports.CreateRuningInfoDto = exports.RunningInfoDtoItems = void 0;
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
const graphql_1 = require("@nestjs/graphql");
const class_info_1 = require("../types/class-info");
let RunningInfoDtoItems = class RunningInfoDtoItems {
};
exports.RunningInfoDtoItems = RunningInfoDtoItems;
__decorate([
    (0, class_validator_1.IsInt)(),
    (0, graphql_1.Field)(() => graphql_1.Int),
    __metadata("design:type", Number)
], RunningInfoDtoItems.prototype, "id", void 0);
__decorate([
    (0, graphql_1.Field)(() => Boolean, { nullable: true }),
    __metadata("design:type", Boolean)
], RunningInfoDtoItems.prototype, "lock_status", void 0);
__decorate([
    (0, graphql_1.Field)(() => String, { nullable: true }),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], RunningInfoDtoItems.prototype, "traySlot", void 0);
__decorate([
    (0, graphql_1.Field)(() => String, { nullable: true }),
    __metadata("design:type", String)
], RunningInfoDtoItems.prototype, "slotNo", void 0);
__decorate([
    (0, graphql_1.Field)(() => String, { nullable: true }),
    __metadata("design:type", String)
], RunningInfoDtoItems.prototype, "barcodeNo", void 0);
__decorate([
    (0, graphql_1.Field)(() => String, { nullable: true }),
    __metadata("design:type", String)
], RunningInfoDtoItems.prototype, "patientId", void 0);
__decorate([
    (0, graphql_1.Field)(() => String, { nullable: true }),
    __metadata("design:type", String)
], RunningInfoDtoItems.prototype, "patientNm", void 0);
__decorate([
    (0, graphql_1.Field)(() => String, { nullable: true }),
    __metadata("design:type", String)
], RunningInfoDtoItems.prototype, "gender", void 0);
__decorate([
    (0, graphql_1.Field)(() => String, { nullable: true }),
    __metadata("design:type", String)
], RunningInfoDtoItems.prototype, "birthDay", void 0);
__decorate([
    (0, graphql_1.Field)(() => String, { nullable: true }),
    __metadata("design:type", String)
], RunningInfoDtoItems.prototype, "slotId", void 0);
__decorate([
    (0, graphql_1.Field)(() => String, { nullable: true }),
    __metadata("design:type", String)
], RunningInfoDtoItems.prototype, "orderDttm", void 0);
__decorate([
    (0, graphql_1.Field)(() => String, { nullable: true }),
    __metadata("design:type", String)
], RunningInfoDtoItems.prototype, "testType", void 0);
__decorate([
    (0, graphql_1.Field)(() => String, { nullable: true }),
    __metadata("design:type", String)
], RunningInfoDtoItems.prototype, "analyzedDttm", void 0);
__decorate([
    (0, graphql_1.Field)(() => String, { nullable: true }),
    __metadata("design:type", String)
], RunningInfoDtoItems.prototype, "tactTime", void 0);
__decorate([
    (0, graphql_1.Field)(() => String, { nullable: true }),
    __metadata("design:type", String)
], RunningInfoDtoItems.prototype, "cassetId", void 0);
__decorate([
    (0, graphql_1.Field)(() => Boolean, { nullable: true }),
    __metadata("design:type", Boolean)
], RunningInfoDtoItems.prototype, "isNormal", void 0);
__decorate([
    (0, graphql_1.Field)(() => String, { nullable: true }),
    __metadata("design:type", String)
], RunningInfoDtoItems.prototype, "submitState", void 0);
__decorate([
    (0, graphql_1.Field)(() => Date, { nullable: true }),
    __metadata("design:type", Date)
], RunningInfoDtoItems.prototype, "submitOfDate", void 0);
__decorate([
    (0, graphql_1.Field)(() => String, { nullable: true }),
    __metadata("design:type", String)
], RunningInfoDtoItems.prototype, "submitUserId", void 0);
__decorate([
    (0, graphql_1.Field)(() => class_info_1.TotalClassInfo, { nullable: true }),
    __metadata("design:type", class_info_1.TotalClassInfo)
], RunningInfoDtoItems.prototype, "classInfo", void 0);
__decorate([
    (0, graphql_1.Field)(() => String, { nullable: true }),
    __metadata("design:type", String)
], RunningInfoDtoItems.prototype, "memo", void 0);
__decorate([
    (0, graphql_1.Field)(() => String, { nullable: true }),
    __metadata("design:type", String)
], RunningInfoDtoItems.prototype, "pcIp", void 0);
__decorate([
    (0, graphql_1.Field)(() => String, { nullable: true }),
    __metadata("design:type", String)
], RunningInfoDtoItems.prototype, "cbcPatientNo", void 0);
__decorate([
    (0, graphql_1.Field)(() => String, { nullable: true }),
    __metadata("design:type", String)
], RunningInfoDtoItems.prototype, "cbcPatientNm", void 0);
__decorate([
    (0, graphql_1.Field)(() => String, { nullable: true }),
    __metadata("design:type", String)
], RunningInfoDtoItems.prototype, "cbcSex", void 0);
__decorate([
    (0, graphql_1.Field)(() => String, { nullable: true }),
    __metadata("design:type", String)
], RunningInfoDtoItems.prototype, "cbcAge", void 0);
__decorate([
    (0, graphql_1.Field)(() => String, { nullable: true }),
    __metadata("design:type", String)
], RunningInfoDtoItems.prototype, "img_drive_root_path", void 0);
exports.RunningInfoDtoItems = RunningInfoDtoItems = __decorate([
    (0, graphql_1.ObjectType)(),
    (0, graphql_1.InputType)()
], RunningInfoDtoItems);
let CreateRuningInfoDto = class CreateRuningInfoDto {
};
exports.CreateRuningInfoDto = CreateRuningInfoDto;
__decorate([
    (0, graphql_1.Field)(() => graphql_1.Int, { nullable: true }),
    (0, class_validator_1.IsInt)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], CreateRuningInfoDto.prototype, "userId", void 0);
__decorate([
    (0, graphql_1.Field)(() => RunningInfoDtoItems),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => RunningInfoDtoItems),
    __metadata("design:type", RunningInfoDtoItems)
], CreateRuningInfoDto.prototype, "runingInfoDtoItems", void 0);
__decorate([
    (0, graphql_1.Field)(() => String),
    __metadata("design:type", Object)
], CreateRuningInfoDto.prototype, "dayQuery", void 0);
exports.CreateRuningInfoDto = CreateRuningInfoDto = __decorate([
    (0, graphql_1.InputType)()
], CreateRuningInfoDto);
let UpdateRuningInfoDto = class UpdateRuningInfoDto {
};
exports.UpdateRuningInfoDto = UpdateRuningInfoDto;
__decorate([
    (0, graphql_1.Field)(() => graphql_1.Int),
    (0, class_validator_1.IsInt)(),
    __metadata("design:type", Number)
], UpdateRuningInfoDto.prototype, "userId", void 0);
__decorate([
    (0, graphql_1.Field)(() => String),
    __metadata("design:type", Object)
], UpdateRuningInfoDto.prototype, "dayQuery", void 0);
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, graphql_1.Field)(() => [RunningInfoDtoItems]),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => RunningInfoDtoItems),
    __metadata("design:type", Array)
], UpdateRuningInfoDto.prototype, "runingInfoDtoItems", void 0);
exports.UpdateRuningInfoDto = UpdateRuningInfoDto = __decorate([
    (0, graphql_1.InputType)()
], UpdateRuningInfoDto);
//# sourceMappingURL=runningInfoDtoItems.js.map