import { TotalClassInfo } from '../types/class-info';
export declare class RunningInfoDtoItems {
    id: number;
    lock_status?: boolean;
    traySlot?: string;
    slotNo?: string;
    barcodeNo?: string;
    patientId?: string;
    patientNm?: string;
    gender?: string;
    birthDay?: string;
    slotId?: string;
    orderDttm?: string;
    testType?: string;
    analyzedDttm?: string;
    tactTime?: string;
    cassetId?: string;
    isNormal?: boolean;
    submitState?: string;
    submitOfDate?: Date;
    submitUserId?: string;
    classInfo?: TotalClassInfo;
    memo?: string;
    pcIp?: string;
    cbcPatientNo?: string;
    cbcPatientNm?: string;
    cbcSex?: string;
    cbcAge?: string;
    img_drive_root_path?: string;
}
export declare class CreateRuningInfoDto {
    userId?: number;
    runingInfoDtoItems: RunningInfoDtoItems;
    dayQuery: any;
}
export declare class UpdateRuningInfoDto {
    userId: number;
    dayQuery: any;
    runingInfoDtoItems: RunningInfoDtoItems[];
}
