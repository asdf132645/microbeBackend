import { RunningInfoService } from './runningInfo.service';
import { CreateRuningInfoDto, UpdateRuningInfoDto } from './dto/runningInfoDtoItems';
import { RunningInfoEntity } from './runningInfo.entity';
import Redis from 'ioredis';
export declare class RunningInfoController {
    private readonly runingInfoService;
    private readonly redis;
    constructor(runingInfoService: RunningInfoService, redis: Redis);
    getPageUpDown(id: string, step: string, type: string, dayQuery: string): Promise<Partial<RunningInfoEntity> | null>;
    clearPcIpAndState(oldPcIp: string, dayQuery: string): Promise<void>;
    updatePcIpAndState(oldPcIp: string, newEntityId: number, newPcIp: string, dayQuery: string): Promise<void>;
    create(createDto: CreateRuningInfoDto): Promise<RunningInfoEntity | null>;
    deleteMultiple(req: any): Promise<{
        success: boolean;
    }>;
    update(updateDto: UpdateRuningInfoDto): Promise<RunningInfoEntity[]>;
    getRunningInfoById(id: string): Promise<RunningInfoEntity | null>;
    getRunningInfoDetailById(id: string): Promise<RunningInfoEntity | null>;
    getRunningInfoClassInfoByIdDetail(id: string): Promise<RunningInfoEntity | null>;
    getRunningInfoClassInfoMenuByIdDetail(id: string): Promise<RunningInfoEntity | null>;
    removePageAllDataApi(): Promise<void>;
    findAllWithPagingAndFilter(page?: number, pageSize?: number, startDay?: string, endDay?: string, barcodeNo?: string, patientId?: string, patientNm?: string, titles?: string, testType?: string): Promise<{
        data: RunningInfoEntity[];
        total: number;
        page: number;
    }>;
}
