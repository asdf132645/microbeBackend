"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RunningInfoModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const runningInfo_entity_1 = require("./runningInfo.entity");
const runningInfo_service_1 = require("./runningInfo.service");
const runningInfo_controller_1 = require("./runningInfo.controller");
const logger_service_1 = require("../logger.service");
const ioredis_1 = require("@nestjs-modules/ioredis");
const runningInfo_resolver_1 = require("./runningInfo.resolver");
let RunningInfoModule = class RunningInfoModule {
};
exports.RunningInfoModule = RunningInfoModule;
exports.RunningInfoModule = RunningInfoModule = __decorate([
    (0, common_1.Module)({
        imports: [
            typeorm_1.TypeOrmModule.forFeature([runningInfo_entity_1.RunningInfoEntity]),
            ioredis_1.RedisModule.forRoot({
                type: 'single',
                url: 'redis://localhost:6379',
            }),
        ],
        providers: [runningInfo_service_1.RunningInfoService, runningInfo_resolver_1.RunningInfoResolver, logger_service_1.LoggerService],
        exports: [runningInfo_service_1.RunningInfoService, runningInfo_resolver_1.RunningInfoResolver],
        controllers: [runningInfo_controller_1.RunningInfoController],
    })
], RunningInfoModule);
//# sourceMappingURL=runningInfo.module.js.map