export declare function isServerRunningLocally(): Promise<string>;
