export declare class Hl7Module {
}
