export declare class CombinedModule {
}
