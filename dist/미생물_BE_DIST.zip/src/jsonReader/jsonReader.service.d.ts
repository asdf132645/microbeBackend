export declare class JsonReaderService {
    readJsonFile(fullPath: string): Promise<any>;
    createJson(file: any, filePath: string): Promise<any>;
}
