export declare class JsonReaderModule {
}
