export declare class FileSystemService {
    createFolder(path: string): Promise<void>;
    deleteFolder(path: string): Promise<void>;
}
