export declare class CbcModule {
}
