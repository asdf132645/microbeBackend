export declare class FileModule {
}
