export declare class DownloadModule {
}
