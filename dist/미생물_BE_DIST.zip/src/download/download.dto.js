"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DownloadReturn = exports.DownloadDto = void 0;
class DownloadDto {
}
exports.DownloadDto = DownloadDto;
class DownloadReturn {
}
exports.DownloadReturn = DownloadReturn;
//# sourceMappingURL=download.dto.js.map