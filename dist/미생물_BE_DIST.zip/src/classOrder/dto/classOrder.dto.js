"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClassOrderDto = void 0;
class ClassOrderDto {
}
exports.ClassOrderDto = ClassOrderDto;
//# sourceMappingURL=classOrder.dto.js.map