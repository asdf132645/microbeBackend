export declare class ClassOrderDto {
    id?: number;
    classId?: string;
    abbreviation?: string;
    fullNm?: string;
    orderIdx?: string;
}
