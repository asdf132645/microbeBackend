export declare class ClassOrderModule {
}
