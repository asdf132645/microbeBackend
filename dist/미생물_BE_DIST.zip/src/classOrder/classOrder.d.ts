export declare class ClassOrder {
    id?: number;
    classId?: string;
    abbreviation?: string;
    fullNm?: string;
    orderIdx?: string;
}
