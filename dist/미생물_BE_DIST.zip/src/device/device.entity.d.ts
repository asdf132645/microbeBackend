export declare class DeviceEntity {
    id: number;
    siteCd: string;
    deviceSerialNm: string;
    pcIp: string;
}
