"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createTypeOrmOptions = void 0;
const user_entity_1 = require("./src/user/entities/user.entity");
const cell_entity_1 = require("./src/settings/analysisDatabse/cellImgAnalyzed/entities/cell.entity");
const gramRange_entity_1 = require("./src/settings/analysisDatabse/gramRange/gramRange.entity");
const imagePrint_entity_1 = require("./src/settings/report/imagePrint/imagePrint.entity");
const cbcCode_entity_1 = require("./src/settings/report/cbcCode/cbcCode.entity");
const filePathSetEntity_1 = require("./src/settings/report/filrPathSet/filePathSetEntity");
const runningInfo_entity_1 = require("./src/runingInfo/runningInfo.entity");
const classOrder_1 = require("./src/classOrder/classOrder");
const dotenv = require("dotenv");
const device_entity_1 = require("./src/device/device.entity");
dotenv.config();
const createTypeOrmOptions = async () => {
    const options = {
        type: 'mysql',
        host: '127.0.0.1',
        port: 3306,
        username: 'root',
        password: 'uimd5191!',
        database: 'mo_db_web',
        synchronize: false,
        migrations: ['src/migrations/**/*{.ts,.js}'],
        entities: [
            user_entity_1.User,
            cell_entity_1.CellImgAnalyzed,
            gramRange_entity_1.GramRange,
            imagePrint_entity_1.ImagePrintEntity,
            cbcCode_entity_1.CbcCodeEntity,
            filePathSetEntity_1.FilePathSetEntity,
            runningInfo_entity_1.RunningInfoEntity,
            classOrder_1.ClassOrder,
            device_entity_1.DeviceEntity,
        ],
        extra: {
            connectionLimit: 20,
            multipleStatements: true,
        },
    };
    return options;
};
exports.createTypeOrmOptions = createTypeOrmOptions;
//# sourceMappingURL=ormconfig.js.map