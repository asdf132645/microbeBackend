import { TypeOrmModuleOptions } from '@nestjs/typeorm';
export declare const createTypeOrmOptions: () => Promise<TypeOrmModuleOptions>;
